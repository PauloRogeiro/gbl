package com.globalte.taskme;

import android.content.Context;

import com.globalte.taskme.business.domain.UserBusiness;
import com.globalte.taskme.business.wrappers.User;

public class ViewModel {

    private UserBusiness userBusiness = new UserBusiness();

    public void addUser(User user, Context context){
        userBusiness.addUser(user,context);
    }


}
