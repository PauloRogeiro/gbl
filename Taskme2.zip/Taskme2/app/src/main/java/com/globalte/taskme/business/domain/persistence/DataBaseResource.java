package com.globalte.taskme.business.domain.persistence;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/***
 * Cria a base de dados
 */
public class DataBaseResource extends SQLiteOpenHelper {

    /*Cria o banco*/
    public DataBaseResource(Context ctx) {
        super(ctx,"task", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        /*Cria a tabela de usuário no banco*/
        db.execSQL(DataBaseResource.getTableUserDDL());
        createDefaultUser(db);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    /**
     *  Cria o usuário master da aplicação
     * @param db
     */
    private void createDefaultUser(SQLiteDatabase db){
        /* valores do insert        * */
        ContentValues contentValues = new ContentValues();
        contentValues.put("Name","ROOT");
        contentValues.put("Mail","Root@Root");
        contentValues.put("Login","Root");
        contentValues.put("Password","123456");
        db.insert("_User", null, contentValues);

    }

    private  static String getTableUserDDL(){
        /*Cria a tabela de usuário */
        StringBuilder ddl = new StringBuilder();
        ddl.append("create table if not exists _User ( " );
        ddl.append("" );
        ddl.append("Id Integer primary key autoincrement not null," );
        ddl.append("Name varchar(100) NOT NULL DEFAULT('')," );
        ddl.append("Mail varchar(100) NOT NULL DEFAULT('')," );
        ddl.append("Login varchar(100) NOT NULL DEFAULT('')," );
        ddl.append("Password varchar(8) NOT NULL DEFAULT('')" );
        ddl.append(");");

        return ddl.toString();

    }


}
