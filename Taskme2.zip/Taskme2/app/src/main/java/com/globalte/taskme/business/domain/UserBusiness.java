package com.globalte.taskme.business.domain;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.globalte.taskme.business.domain.persistence.PersistenceService;
import com.globalte.taskme.business.wrappers.User;

public class UserBusiness {


    /**
     * @param login do usuário
     * @param password do usuário
     * @param context contexto de uso. Aplicação, atividade, serviço
     * @return Usuário logado
     */
    public  User login(String login, String password, Context context) {

        if (login == null || login.isEmpty()){

            throw new RuntimeException("inválid login");

        }

        if (password == null || password.isEmpty()){

            throw new RuntimeException("inválid password");

        }

        if (context == null ){

            throw new RuntimeException("contexto inválido");

        }

        User loggedUser = null;

        Cursor cursor = PersistenceService.getInstance(context).getDatabase().query(
                                                    "_User",
                                                     new String[]{"name", "mail", "login", "password"},
                                                    "mail = ? AND password = ?",
                                                     new String[]{login,password},
                                                    null,
                                                    null,
                                                    null);

        if(cursor.moveToFirst()){
            loggedUser = new User();
            loggedUser.setNome(cursor.getString(0));
            loggedUser.setMail(cursor.getString(1));
            loggedUser.setLogin(cursor.getString(2));
            loggedUser.setPassword(cursor.getString(3));
        }

        return loggedUser;
    }

    /**
     * @param user usuário a ser inserido
     * @param context contexto de uso. Aplicação, atividade, serviço
     * @return usuário inserido
     */
    public User addUser(User user, Context context) {

        if (user == null || user.getNome().isEmpty()){

            throw new RuntimeException("Nome inválido");

        }


        if (user == null || user.getMail().isEmpty()){

            throw new RuntimeException("Email inválido");

        }

        if (user == null || user.getPassword().isEmpty()){

            throw new RuntimeException("Password inválido");

        }

        if (context == null ){

            throw new RuntimeException("contexto inválido");

        }

        User loggedUser = null;

        ContentValues contentValues = new ContentValues();
        contentValues.put("Name",user.getNome());
        contentValues.put("Mail",user.getMail());
        contentValues.put("Password",user.getPassword());
        user.setId((int)PersistenceService.getInstance(context).getDatabase().insert("_User", null, contentValues));

        return user.getId() == -1? null: user;
    }


}
