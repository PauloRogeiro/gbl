package com.globalte.taskme;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.globalte.taskme.business.domain.UserBusiness;
import com.globalte.taskme.business.wrappers.User;
import com.globalte.taskme.databinding.ActivityRegisterBinding;

public class RegisterActivity extends AppCompatActivity {

    private UserBusiness userBusiness = new UserBusiness();


    public void addUser(User user){
        userBusiness.addUser(user,this) ;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityRegisterBinding binding = DataBindingUtil.setContentView( this, R.layout.activity_register);

        User user = new User();
        user.setNome("fernando alberto");
        user.setMail("joao@uau");
        user.setPassword("12345678");

        binding.setUser(user);
        binding.setModel(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


    }

}
