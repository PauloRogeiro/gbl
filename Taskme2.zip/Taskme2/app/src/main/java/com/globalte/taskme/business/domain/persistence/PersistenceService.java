package com.globalte.taskme.business.domain.persistence;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;

public class PersistenceService {


    private SQLiteDatabase database;
    private static PersistenceService instance;

    private PersistenceService (Context context){
       super();
       database = new DataBaseResource(context).getWritableDatabase();
    }


    public static PersistenceService getInstance(Context context){

        if (instance == null ){
            instance = new    PersistenceService(context);

        }

        return instance;
    }

    public SQLiteDatabase getDatabase (){

        return database;
    }


}
